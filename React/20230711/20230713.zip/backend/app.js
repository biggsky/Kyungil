const express = require("express")
const cookieParser = require('cookie-parser');
const cors = require("cors")
const app = express();

app.use(cors({
    origin : ["http://localhost:3000"],
    credentials : true
}))
app.use(cookieParser());

app.post('/dd', (req, res) => {
  const token = "dsfsdfsdfagewfaefasgsdgasdfs";
    console.log(req.cookies)
  if (token) {
    res.cookie('token', token, { httpOnly: true }); // 요청과 응답에 관해서만 자바스크립트로 제어하는게 아니고
    res.send("성공");
  }
});



app.listen(8000, ()=>{
    console.log("server on~")
})