import React, { useState } from 'react';
import axios from 'axios';

const LoginForm = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:8000/dd',{id:1,pw:2}, {withCredentials : true});

      if (response.data.success) {
        console.log("성공")
      }
    } catch (error) {
      console.log("실패");
    }
  };

  return (
    <form onSubmit={handleFormSubmit}>
      <input onChange={setUsername}></input>
      <input onChange={setPassword}></input>
      <button>누름</button>
    </form>
  );
};

export default LoginForm;




